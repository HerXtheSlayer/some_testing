import internal.GlobalVariable as GlobalVariable

